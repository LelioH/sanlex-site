import { useMemo, useState } from "react";
import config from "../site.config";
import { useStore } from "../store/StoreContext";
import ProductCard from "./ProductCard";

type SortKey = "rel" | "asc" | "desc" | "az";

interface CatalogProps {
  filter: string;
  setFilter: (id: string) => void;
}

export default function Catalog({ filter, setFilter }: CatalogProps) {
  const { fav } = useStore();
  const [sort, setSort] = useState<SortKey>("rel");

  const chips = useMemo(() => {
    const base = [{ id: "all", name: "Todos" }, ...config.categories, { id: "fav", name: "Favoritos" }];
    return base.map((c) => {
      let n: number;
      if (c.id === "all") n = config.products.length;
      else if (c.id === "fav") n = Object.keys(fav).length;
      else n = config.products.filter((p) => p.cats.includes(c.id)).length;
      return { id: c.id, name: c.name, n };
    });
  }, [fav]);

  const list = useMemo(() => {
    let l = config.products.slice();
    if (filter === "fav") l = l.filter((p) => fav[p.ref]);
    else if (filter !== "all") l = l.filter((p) => p.cats.includes(filter));
    if (sort === "asc") l.sort((a, b) => a.price - b.price);
    else if (sort === "desc") l.sort((a, b) => b.price - a.price);
    else if (sort === "az") l.sort((a, b) => a.name.localeCompare(b.name, "pt"));
    return l;
  }, [filter, sort, fav]);

  return (
    <section className="section" id="colecao" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <div className="sec-head">
          <div>
            <span className="eyebrow">Catálogo</span>
            <h2>A coleção {config.brand.name}</h2>
          </div>
          <p>Preços de varejo. Lojista? Veja as <a href="#atacado">condições de atacado</a>.</p>
        </div>

        <div className="controls">
          <div className="filters">
            {chips.map((c) => (
              <button
                key={c.id}
                className={"chip" + (filter === c.id ? " active" : "")}
                onClick={() => setFilter(c.id)}
              >
                {c.name}<span className="n">{c.n}</span>
              </button>
            ))}
          </div>
          <div className="sortbox">
            <label htmlFor="sort">Ordenar</label>
            <select id="sort" value={sort} onChange={(e) => setSort(e.target.value as SortKey)}>
              <option value="rel">Relevância</option>
              <option value="asc">Menor preço</option>
              <option value="desc">Maior preço</option>
              <option value="az">Nome A–Z</option>
            </select>
          </div>
        </div>

        <div className="grid">
          {list.length ? (
            list.map((p) => <ProductCard key={p.ref} product={p} />)
          ) : (
            <div className="empty">
              <h3>Nada por aqui ainda</h3>
              <p>{filter === "fav"
                ? "Toque no coração das peças que você ama para guardá-las aqui."
                : "Tente outra categoria."}</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
